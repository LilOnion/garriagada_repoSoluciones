#include <stdio.h>

int main()
{
		
int dias, segundos;

printf("Ingrese la cantidad de dias""\n");
scanf("%d", & dias);
printf("\n");

segundos=dias*86.400;

printf("%d dias son %d segundos", dias, segundos);

return 0;
}
